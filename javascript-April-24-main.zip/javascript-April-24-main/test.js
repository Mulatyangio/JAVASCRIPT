let date1 = new Date("12/12/2025")
let date2 = new Date("1/05/2025")

console.log( date1.getMonth() );
console.log( date2.getMonth() );
// date module - moment js, date js
