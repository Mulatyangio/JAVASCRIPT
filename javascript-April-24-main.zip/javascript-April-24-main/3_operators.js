console.log(56%5); // 1


let num = 8
console.log( num **=2 ); // num = num ** 2  // 64
console.log( num +=10 ); // num = num + 10 //74
console.log( num %=10 ); // num = num % 10 // 4
console.log(8 !== 8); // false
console.log(!true); // false

let myVal = 97
console.log(myVal>30  || myVal<50); // true

let category = myVal>60 ? "old" : "young"

console.log(category);